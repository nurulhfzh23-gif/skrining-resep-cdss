/**
 * CDSS — Dashboard Skrining Resep Otomatis
 * Membaca data dari data_resep_skrining_200.csv, melakukan skrining
 * administratif, farmasetik, dan klinis secara otomatis, lalu menampilkan
 * KPI, grafik (Chart.js), tabel interaktif, dan modal detail.
 */

// ============================================================
// BAGIAN 1: PARSING CSV
// ============================================================

/**
 * Mengurai string CSV menjadi array of object.
 * Mendukung nilai yang dikutip (quoted) dan koma di dalam tanda kutip.
 */
function parseCSV(text) {
  // Hapus BOM (byte-order mark) jika ada
  text = text.replace(/^\uFEFF/, '');
  const lines = text.split(/\r?\n/).filter(l => l.trim() !== '');
  const headers = splitCSVLine(lines[0]);
  return lines.slice(1).map(line => {
    const values = splitCSVLine(line);
    const obj = {};
    headers.forEach((h, i) => { obj[h.trim()] = (values[i] || '').trim(); });
    return obj;
  });
}

/** Memisahkan satu baris CSV dengan mempertimbangkan tanda kutip. */
function splitCSVLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
      else { inQuotes = !inQuotes; }
    } else if (ch === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += ch;
    }
  }
  result.push(current);
  return result;
}

// ============================================================
// BAGIAN 2: MESIN SKRINING RESEP
// ============================================================

/**
 * Daftar interaksi obat terkurasi.
 * Setiap entri mendefinisikan daftar obat yang harus hadir bersamaan (semua items).
 */
const INTERAKSI_OBAT = [
  {
    id: 'amlodipine-simvastatin',
    tingkat: 'MAYOR',
    items: ['amlodipine', 'simvastatin'],
    kondisi: (obatList) => {
      // Hanya Mayor jika Simvastatin > 20 mg/hari
      const simva = obatList.find(o => /simvastatin/i.test(o));
      if (!simva) return false;
      const doseMatch = simva.match(/(\d+)\s*mg/i);
      return doseMatch && parseInt(doseMatch[1]) > 20;
    },
    deskripsi: 'Amlodipine + Simvastatin (>20 mg/hari): Risiko miopati/rhabdomyolisis.'
  },
  {
    id: 'warfarin-nsaid',
    tingkat: 'MAYOR',
    items: ['warfarin'],
    kondisi: (obatList) => {
      const nsaids = ['ibuprofen', 'asam mefenamat', 'natrium diklofenak', 'na diklofenak', 'diclofenac'];
      return obatList.some(o => nsaids.some(n => o.toLowerCase().includes(n)));
    },
    deskripsi: 'Warfarin + NSAID: Risiko perdarahan saluran cerna.'
  },
  {
    id: 'cipro-teofilin',
    tingkat: 'MAYOR',
    items: ['ciprofloxacin', 'teofilin'],
    kondisi: null,
    deskripsi: 'Ciprofloxacin + Teofilin: Toksisitas teofilin akibat inhibisi CYP1A2.'
  },
  {
    id: 'captopril-spiro-ksr',
    tingkat: 'MAYOR',
    items: ['captopril', 'spironolactone', 'kalium klorida'],
    kondisi: null,
    deskripsi: 'Captopril + Spironolactone + Kalium Klorida (KSR): Risiko hiperkalemia berat.'
  },
  {
    id: 'cipro-antasida',
    tingkat: 'MODERAT',
    items: ['ciprofloxacin', 'antasida'],
    kondisi: null,
    deskripsi: 'Ciprofloxacin + Antasida: Penurunan absorpsi Ciprofloxacin akibat kelasi (jeda 2-6 jam).'
  },
  {
    id: 'captopril-nsaid',
    tingkat: 'MODERAT',
    items: ['captopril'],
    kondisi: (obatList) => {
      const nsaids = ['ibuprofen', 'natrium diklofenak', 'na diklofenak', 'asam mefenamat'];
      return obatList.some(o => nsaids.some(n => o.toLowerCase().includes(n)));
    },
    // Hanya jika bukan kombinasi Mayor (Spiro+KSR)
    extra: (obatList) => {
      const hasSpiro = obatList.some(o => /spironolactone/i.test(o));
      const hasKSR   = obatList.some(o => /kalium klorida|ksr/i.test(o));
      return !(hasSpiro && hasKSR);
    },
    deskripsi: 'Captopril + NSAID: Penurunan efek antihipertensi & risiko nefrotoksisitas.'
  }
];

/**
 * Melakukan skrining penuh pada satu record resep.
 * Mengembalikan objek hasil dengan flag tiap aspek dan rekomendasi.
 */
function skriningResep(r) {
  const result = {
    // --- Kajian Administratif ---
    admin: {
      ok: true,
      masalah: []
    },
    // --- Kajian Farmasetik ---
    farmasi: {
      ok: true,
      masalah: []
    },
    // --- Kajian Klinis & Interaksi ---
    klinis: {
      ok: true,
      masalah: [],
      interaksi: []  // { tingkat, deskripsi }
    },
    // --- Status Akhir ---
    statusLolos: true,
    kategoriMasalah: [],   // 'administratif', 'farmasetik', 'klinis'
    rekomendasi: ''
  };

  const obatRaw = r['daftar_obat_dan_signa'] || '';
  const usia    = r['usia_tahun'] !== '' ? parseFloat(r['usia_tahun']) : null;
  const bb      = r['berat_badan_kg'] !== '' ? parseFloat(r['berat_badan_kg']) : null;

  // Daftar nama obat (lowercase) dari kolom daftar_obat_dan_signa
  // Setiap entri dipisahkan ";"
  const obatList = obatRaw.split(';').map(s => s.trim()).filter(Boolean);
  const obatNamaLower = obatList.map(o => o.toLowerCase());

  // ---- 2a. KAJIAN ADMINISTRATIF ----

  if (!r['tanggal_resep'] || r['tanggal_resep'].trim() === '') {
    result.admin.masalah.push('Tanggal resep tidak tercantum.');
    result.admin.ok = false;
  }
  if (!r['nama_dokter'] || r['nama_dokter'].trim() === '') {
    result.admin.masalah.push('Nama dokter tidak tercantum.');
    result.admin.ok = false;
  }
  if (!r['no_sip_dokter'] || r['no_sip_dokter'].trim() === '') {
    result.admin.masalah.push('Nomor SIP dokter tidak tercantum.');
    result.admin.ok = false;
  }
  if (!r['paraf_dokter'] || r['paraf_dokter'].toLowerCase() !== 'ada') {
    result.admin.masalah.push('Paraf dokter tidak ada.');
    result.admin.ok = false;
  }
  if (!r['no_rm'] || r['no_rm'].trim() === '') {
    result.admin.masalah.push('Nomor rekam medis tidak tercantum.');
    result.admin.ok = false;
  }
  if (!r['nama_pasien'] || r['nama_pasien'].trim() === '') {
    result.admin.masalah.push('Nama pasien tidak tercantum.');
    result.admin.ok = false;
  }
  if (!r['jenis_kelamin'] || r['jenis_kelamin'].trim() === '') {
    result.admin.masalah.push('Jenis kelamin pasien tidak tercantum.');
    result.admin.ok = false;
  }
  if (usia === null) {
    result.admin.masalah.push('Usia pasien tidak tercantum.');
    result.admin.ok = false;
  }
  // Berat badan wajib untuk anak < 18 tahun
  if (usia !== null && usia < 18 && (bb === null || isNaN(bb))) {
    result.admin.masalah.push('Berat badan pasien anak (<18 th) wajib dicantumkan untuk perhitungan dosis.');
    result.admin.ok = false;
  }

  // ---- 2b. KAJIAN FARMASETIK ----

  for (const signa of obatList) {
    const low = signa.toLowerCase();

    // 1. Periksa bentuk sediaan
    const bentukOk = /\b(tab|kapl|caps|syr|krim|tetes mata|tetes telinga|tetes|inhaler|drop|gel|suppositoria|patch|fls|tube)\b/i.test(signa);
    if (!bentukOk) {
      result.farmasi.masalah.push(`Bentuk sediaan tidak jelas pada: "${signa.substring(0,60)}".`);
      result.farmasi.ok = false;
    }

    // 2. Periksa kekuatan sediaan (mg, %, mg/5mL dll.)
    const kekuatanOk = /\d+\s*(mg|mcg|g|%|iu|me)\b/i.test(signa);
    if (!kekuatanOk) {
      result.farmasi.masalah.push(`Kekuatan sediaan tidak tercantum pada: "${signa.substring(0,60)}".`);
      result.farmasi.ok = false;
    }

    // 3. Periksa aturan pakai "S ue" tanpa detail tambahan
    if (/\bS\s*ue\b/i.test(signa) && !/\bS\s*ue\b.*\b(dd|kali|hari|pagi|malam|sore|sekali|dua|tiga)\b/i.test(signa)) {
      result.farmasi.masalah.push(`Aturan pakai "S ue" kurang spesifik pada: "${signa.substring(0,60)}".`);
      result.farmasi.ok = false;
    }

    // 4. Inkompatibilitas: Omeprazole/sediaan lepas tunda yang diinstruksikan digerus/puyer
    if (/omeprazole/i.test(signa) && /gerus|puyer/i.test(signa)) {
      result.farmasi.masalah.push('Omeprazole kapsul lepas tunda (enteric-coated) TIDAK BOLEH digerus/puyer — merusak lapisan pelindung dan menyebabkan degradasi asam.');
      result.farmasi.ok = false;
    }

    // 5. Ciprofloxacin tetes: spesifikasi tetes mata vs telinga tidak jelas
    if (/ciprofloxacin tetes/i.test(low) && !/tetes (mata|telinga)/i.test(low)) {
      result.farmasi.masalah.push(`Spesifikasi sediaan tetes tidak jelas (tetes mata/telinga) pada: "${signa.substring(0,60)}".`);
      result.farmasi.ok = false;
    }
  }

  // Deduplikasi pesan farmasi
  result.farmasi.masalah = [...new Set(result.farmasi.masalah)];

  // ---- 2c. KAJIAN KLINIS & INTERAKSI OBAT ----

  // c1. Cek kesesuaian dosis anak: Paracetamol
  if (usia !== null && usia < 18 && bb !== null) {
    for (const signa of obatList) {
      if (/paracetamol/i.test(signa)) {
        const doseMatch = signa.match(/paracetamol\s+(\d+)\s*mg/i);
        if (doseMatch) {
          const doseMg = parseInt(doseMatch[1]);
          // Frekuensi dari signa: "S 3 dd" → 3x, "S 2 dd" → 2x, dsb.
          const frekMatch = signa.match(/S\s+(\d+)\s+dd/i);
          const frek = frekMatch ? parseInt(frekMatch[1]) : 3; // default 3x jika tidak terdeteksi
          const doseMaks = 15 * bb; // 10-15 mg/kgBB/kali, gunakan batas atas 15
          if (doseMg > doseMaks) {
            result.klinis.masalah.push(
              `Overdosis anak: Paracetamol ${doseMg} mg/kali melebihi dosis maksimal ` +
              `(15 mg/kgBB × ${bb} kg = ${doseMaks} mg/kali). Total harian: ${doseMg * frek} mg.`
            );
            result.klinis.ok = false;
          }
        }
      }
    }
  }

  // c2. Duplikasi terapi: Dua atau lebih NSAID bersamaan
  const nsaidList = ['asam mefenamat', 'ibuprofen', 'natrium diklofenak', 'na diklofenak',
                     'meloxicam', 'piroxicam', 'ketoprofen', 'diclofenac', 'ketorolac'];
  const nsaidDiresepkan = nsaidList.filter(n => obatNamaLower.some(o => o.includes(n)));
  if (nsaidDiresepkan.length >= 2) {
    result.klinis.masalah.push(
      `Duplikasi terapi NSAID: ${nsaidDiresepkan.join(' + ')} ` +
      `— dua NSAID bersamaan meningkatkan risiko perdarahan GI tanpa tambahan efikasi.`
    );
    result.klinis.ok = false;
  }

  // c3. Kontraindikasi alergi Penisilin dengan Amoxicillin
  const alergi = (r['riwayat_alergi'] || '').toLowerCase();
  if (/penisilin|penicillin/.test(alergi)) {
    if (obatNamaLower.some(o => /amoxicillin|amoksisilin/.test(o))) {
      result.klinis.masalah.push(
        'Kontraindikasi Alergi: Pasien memiliki riwayat alergi Penisilin, namun diresepkan Amoxicillin (golongan β-laktam).'
      );
      result.klinis.ok = false;
    }
  }

  // c4. Kontraindikasi kehamilan: ACE Inhibitor (Captopril, Lisinopril, Enalapril)
  const diagnosis = (r['diagnosis_klinis'] || '').toLowerCase();
  const isHamil = /hamil|kehamilan|g\d+p\d+/i.test(diagnosis);
  if (isHamil) {
    if (obatNamaLower.some(o => /captopril|lisinopril|enalapril|ramipril|perindopril/.test(o))) {
      result.klinis.masalah.push(
        'Kontraindikasi Kehamilan (Mutlak): ACE Inhibitor bersifat teratogenik — dapat menyebabkan fetotoksisitas pada trimester 2-3. Ganti dengan Metildopa atau Nifedipine.'
      );
      result.klinis.ok = false;
    }
  }

  // c5. Interaksi obat terkurasi
  for (const iad of INTERAKSI_OBAT) {
    // Cek apakah semua item dalam definisi hadir dalam resep
    const semuaAda = iad.items.every(item => obatNamaLower.some(o => o.includes(item.toLowerCase())));
    if (!semuaAda) continue;

    // Cek kondisi tambahan jika ada
    if (iad.kondisi && !iad.kondisi(obatList)) continue;
    if (iad.extra && !iad.extra(obatList)) continue;

    result.klinis.interaksi.push({ tingkat: iad.tingkat, deskripsi: iad.deskripsi });
    result.klinis.ok = false;
  }

  // ---- 2d. STATUS AKHIR & REKOMENDASI ----

  if (!result.admin.ok)   result.kategoriMasalah.push('administratif');
  if (!result.farmasi.ok) result.kategoriMasalah.push('farmasetik');
  if (!result.klinis.ok)  result.kategoriMasalah.push('klinis');

  result.statusLolos = result.kategoriMasalah.length === 0;

  // Susun rekomendasi tindak lanjut
  const rek = [];
  if (!result.admin.ok) {
    rek.push('Kembalikan resep ke dokter untuk melengkapi data administratif yang kurang.');
  }
  if (!result.farmasi.ok) {
    rek.push('Hubungi dokter untuk klarifikasi bentuk/kekuatan sediaan dan aturan pakai.');
  }
  if (result.klinis.interaksi.some(i => i.tingkat === 'MAYOR')) {
    rek.push('⛔ TAHAN resep — Interaksi MAYOR terdeteksi. Segera hubungi dokter penulis resep untuk penggantian/penyesuaian terapi.');
  } else if (result.klinis.interaksi.some(i => i.tingkat === 'MODERAT')) {
    rek.push('⚠ Interaksi MODERAT: Informasikan dokter dan pantau pasien. Pertimbangkan penyesuaian jadwal pemberian.');
  }
  if (result.klinis.masalah.length > 0 && result.klinis.interaksi.length === 0) {
    rek.push('Hubungi dokter untuk klarifikasi masalah klinis (dosis anak, duplikasi, kontraindikasi).');
  }
  if (result.statusLolos) {
    rek.push('✓ Resep lolos skrining — dapat langsung diproses untuk dispensing.');
  }

  result.rekomendasi = rek.join(' ');
  return result;
}

// ============================================================
// BAGIAN 3: STATE APLIKASI & DATA MASTER
// ============================================================

let masterData   = [];   // seluruh record + hasil skrining
let filteredData = [];   // data setelah filter aktif
let charts       = {};   // referensi instance Chart.js

// ============================================================
// BAGIAN 4: RENDERING KOMPONEN UI
// ============================================================

/** Memperbarui angka pada KPI card. */
function renderKPI(data) {
  const total  = data.length;
  const lolos  = data.filter(d => d._hasil.statusLolos).length;
  const tahan  = total - lolos;
  const mayor  = data.filter(d => d._hasil.klinis.interaksi.some(i => i.tingkat === 'MAYOR')).length;

  document.getElementById('kpi-total').textContent = total;
  document.getElementById('kpi-lolos').textContent = lolos;
  document.getElementById('kpi-lolos-pct').textContent =
    total > 0 ? `${((lolos/total)*100).toFixed(1)}% dari total resep` : '—';
  document.getElementById('kpi-tahan').textContent = tahan;
  document.getElementById('kpi-tahan-pct').textContent =
    total > 0 ? `${((tahan/total)*100).toFixed(1)}% dari total resep` : '—';
  document.getElementById('kpi-mayor').textContent = mayor;
}

/** Helper: membuat atau memperbarui chart. Jika sudah ada, destroy dulu. */
function upsertChart(id, config) {
  if (charts[id]) { charts[id].destroy(); }
  const ctx = document.getElementById(id).getContext('2d');
  charts[id] = new Chart(ctx, config);
}

/** Warna palet medis konsisten. */
const PALETTE = {
  teal:    'rgba(13,148,136,0.85)',
  emerald: 'rgba(16,185,129,0.85)',
  slate:   'rgba(100,116,139,0.85)',
  red:     'rgba(239,68,68,0.85)',
  orange:  'rgba(249,115,22,0.85)',
  yellow:  'rgba(234,179,8,0.85)',
  sky:     'rgba(14,165,233,0.85)',
  violet:  'rgba(124,92,216,0.85)',
};

/** Tren Resep Harian — line chart. */
function renderChartTren(data) {
  // Hitung resep per tanggal
  const map = {};
  data.forEach(d => {
    const tgl = d['tanggal_resep'] || 'Tdk Ada Tgl';
    map[tgl] = (map[tgl] || 0) + 1;
  });
  const sorted = Object.keys(map).sort();
  const labels = sorted.map(d => {
    if (!d || d === 'Tdk Ada Tgl') return 'T/A';
    try { return new Date(d).toLocaleDateString('id-ID', { day:'numeric', month:'short' }); }
    catch { return d; }
  });

  upsertChart('chart-tren', {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Jumlah Resep',
        data: sorted.map(d => map[d]),
        borderColor: PALETTE.teal,
        backgroundColor: 'rgba(13,148,136,0.12)',
        borderWidth: 2,
        pointRadius: 4,
        pointBackgroundColor: PALETTE.teal,
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { mode: 'index' } },
      scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
  });
}

/** Distribusi Masalah Skrining — doughnut chart. */
function renderChartDistribusi(data) {
  const admin   = data.filter(d => d._hasil.kategoriMasalah.includes('administratif')).length;
  const farmasi = data.filter(d => d._hasil.kategoriMasalah.includes('farmasetik')).length;
  const klinis  = data.filter(d => d._hasil.kategoriMasalah.includes('klinis')).length;
  const lolos   = data.filter(d => d._hasil.statusLolos).length;

  // Polar Area Chart: setiap sektor memiliki radius proporsional dengan nilai,
  // sehingga perbandingan proporsi lebih mudah dibaca secara visual.
  upsertChart('chart-distribusi', {
    type: 'polarArea',
    data: {
      labels: ['Lolos', 'Administratif', 'Farmasetik', 'Klinis/Interaksi'],
      datasets: [{
        data: [lolos, admin, farmasi, klinis],
        backgroundColor: [
          'rgba(16,185,129,0.75)',   // emerald — lolos
          'rgba(249,115,22,0.75)',   // orange  — administratif
          'rgba(234,179,8,0.75)',    // yellow  — farmasetik
          'rgba(239,68,68,0.75)'    // red     — klinis
        ],
        borderColor: ['#059669', '#ea580c', '#ca8a04', '#dc2626'],
        borderWidth: 1.5
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom', labels: { font: { size: 11 }, boxWidth: 14, padding: 10 } },
        tooltip: {
          callbacks: {
            label: (ctx) => {
              const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
              const pct = total > 0 ? ((ctx.parsed.r / total) * 100).toFixed(1) : 0;
              return ` ${ctx.label}: ${ctx.parsed.r} resep (${pct}%)`;
            }
          }
        }
      },
      scales: {
        r: {
          beginAtZero: true,
          ticks: { stepSize: 5, font: { size: 10 } },
          grid: { color: 'rgba(100,116,139,0.15)' }
        }
      }
    }
  });
}

/** Proporsi Tingkat Keparahan Interaksi Obat — bar chart. */
function renderChartInteraksi(data) {
  let mayor = 0, moderat = 0, noInteraksi = 0;
  data.forEach(d => {
    const iad = d._hasil.klinis.interaksi;
    if (iad.some(i => i.tingkat === 'MAYOR'))        mayor++;
    else if (iad.some(i => i.tingkat === 'MODERAT')) moderat++;
    else                                              noInteraksi++;
  });

  upsertChart('chart-interaksi', {
    type: 'bar',
    data: {
      labels: ['Mayor', 'Moderat', 'Tanpa Interaksi'],
      datasets: [{
        label: 'Jumlah Resep',
        data: [mayor, moderat, noInteraksi],
        backgroundColor: [PALETTE.red, PALETTE.yellow, PALETTE.emerald],
        borderRadius: 6
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
  });
}

/** Beban Resep per Dokter — horizontal bar chart. */
function renderChartDokter(data) {
  const map = {};
  data.forEach(d => {
    const nama = d['nama_dokter'] || 'Tidak Diketahui';
    map[nama] = (map[nama] || 0) + 1;
  });
  const sorted = Object.entries(map).sort((a, b) => b[1] - a[1]);

  upsertChart('chart-dokter', {
    type: 'bar',
    data: {
      labels: sorted.map(([k]) => k),
      datasets: [{
        label: 'Jumlah Resep',
        data: sorted.map(([,v]) => v),
        backgroundColor: sorted.map((_, i) => Object.values(PALETTE)[i % Object.keys(PALETTE).length]),
        borderRadius: 6
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { x: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
  });
}

/** Memperbarui semua grafik sekaligus. */
function renderAllCharts(data) {
  renderChartTren(data);
  renderChartDistribusi(data);
  renderChartInteraksi(data);
  renderChartDokter(data);
}

// ============================================================
// BAGIAN 5: TABEL INTERAKTIF
// ============================================================

/** Badge HTML untuk status check per aspek. */
function badgeCheck(ok) {
  return ok
    ? '<span class="inline-flex items-center gap-0.5 bg-emerald-50 text-emerald-700 rounded-full px-2 py-0.5 text-xs font-medium">✓ OK</span>'
    : '<span class="inline-flex items-center gap-0.5 bg-red-50 text-red-700 rounded-full px-2 py-0.5 text-xs font-medium">✗ Ada</span>';
}

/** Badge status akhir resep. */
function badgeStatus(lolos) {
  return lolos
    ? '<span class="badge-lolos inline-block bg-emerald-100 text-emerald-700 rounded-full px-2.5 py-0.5 text-xs font-semibold">✓ Lolos</span>'
    : '<span class="badge-tahan inline-block bg-red-100 text-red-700 rounded-full px-2.5 py-0.5 text-xs font-semibold animate-pulse">⚠ Tahan</span>';
}

/** Merender baris tabel dari data terfilter. */
function renderTable(data) {
  const tbody = document.getElementById('table-body');
  const empty = document.getElementById('table-empty');
  const count = document.getElementById('table-count');

  tbody.innerHTML = '';
  count.textContent = `${data.length} resep`;

  if (data.length === 0) {
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  data.forEach((r, idx) => {
    const h = r._hasil;
    const tr = document.createElement('tr');
    tr.className = 'hover:bg-slate-50 transition-colors cursor-default';
    tr.innerHTML = `
      <td class="px-3 py-2 font-mono text-teal-700 font-medium">${r['no_resep']}</td>
      <td class="px-3 py-2 text-slate-500">${r['tanggal_resep'] || '<span class="text-red-400">—</span>'}</td>
      <td class="px-3 py-2">
        <div class="font-medium text-slate-700">${r['nama_pasien']}</div>
        <div class="text-slate-400">${r['no_rm']} · ${r['jenis_kelamin']} · ${r['usia_tahun'] || '?'} th</div>
      </td>
      <td class="px-3 py-2 text-slate-600">${r['nama_dokter']}</td>
      <td class="px-3 py-2 text-center">${badgeCheck(h.admin.ok)}</td>
      <td class="px-3 py-2 text-center">${badgeCheck(h.farmasi.ok)}</td>
      <td class="px-3 py-2 text-center">${badgeCheck(h.klinis.ok)}</td>
      <td class="px-3 py-2">${badgeStatus(h.statusLolos)}</td>
      <td class="px-3 py-2 text-center">
        <button class="btn-detail text-xs bg-teal-50 hover:bg-teal-100 text-teal-700 rounded-lg px-2 py-1 transition-colors" data-idx="${idx}">
          Lihat
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Event listener tombol detail
  tbody.querySelectorAll('.btn-detail').forEach(btn => {
    btn.addEventListener('click', () => openModal(filteredData[parseInt(btn.dataset.idx)]));
  });
}

// ============================================================
// BAGIAN 6: MODAL DETAIL
// ============================================================

// ============================================================
// BAGIAN 6a: GENERATOR CATATAN SBAR
// ============================================================

/**
 * Membangun teks Catatan Konfirmasi SBAR (Situation–Background–Assessment–Recommendation)
 * untuk dikomunikasikan apoteker kepada dokter penulis resep.
 */
function buildSBAR(r) {
  const h   = r._hasil;
  const tgl = r['tanggal_resep'] || '[tgl tidak ada]';
  const now = new Date().toLocaleDateString('id-ID', { day:'numeric', month:'long', year:'numeric', hour:'2-digit', minute:'2-digit' });

  // Kumpulkan semua masalah
  const semuaMasalah = [
    ...h.admin.masalah.map(m => `[ADMIN] ${m}`),
    ...h.farmasi.masalah.map(m => `[FARMASI] ${m}`),
    ...h.klinis.masalah.map(m => `[KLINIS] ${m}`),
    ...h.klinis.interaksi.map(i => `[INTERAKSI ${i.tingkat}] ${i.deskripsi}`)
  ];

  const masalahTeks = semuaMasalah.length > 0
    ? semuaMasalah.map((m, i) => `  ${i + 1}. ${m}`).join('\n')
    : '  — Tidak ada masalah terdeteksi.';

  return `=========================================
CATATAN KONFIRMASI RESEP — SBAR
Dibuat oleh: Instalasi Farmasi
Waktu     : ${now}
=========================================

[S] SITUATION — Situasi
-----------------------------------------
Resep No. ${r['no_resep']} (tgl. ${tgl}) atas nama pasien ${r['nama_pasien']}
(${r['no_rm']}, ${r['jenis_kelamin']}, ${r['usia_tahun'] || '?'} th, BB: ${r['berat_badan_kg'] || '?'} kg)
yang ditulis oleh ${r['nama_dokter']}
saat ini DITAHAN oleh Apoteker karena terdapat masalah yang memerlukan konfirmasi.

[B] BACKGROUND — Latar Belakang
-----------------------------------------
Diagnosis   : ${r['diagnosis_klinis']}
Riwayat Alergi: ${r['riwayat_alergi'] || 'Tidak ada'}
Daftar Obat :
${r['daftar_obat_dan_signa'].split(';').filter(Boolean).map(o => `  • ${o.trim()}`).join('\n')}

[A] ASSESSMENT — Temuan Skrining
-----------------------------------------
${masalahTeks}

[R] RECOMMENDATION — Rekomendasi Apoteker
-----------------------------------------
${h.rekomendasi}

-----------------------------------------
Mohon konfirmasi/tanggapan dokter sesegera mungkin.
Terima kasih atas kerjasamanya.
=========================================`;
}

/** Membuka modal dengan data detail skrining satu resep. */
function openModal(r) {
  const h = r._hasil;
  document.getElementById('modal-title').textContent = `Detail Skrining: ${r['no_resep']}`;
  document.getElementById('modal-subtitle').textContent =
    `${r['nama_pasien']} · ${r['diagnosis_klinis']}`;

  const statusHtml = h.statusLolos
    ? '<div class="bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg px-4 py-2 text-sm font-semibold">✓ Status Akhir: LOLOS DISPENSING</div>'
    : '<div class="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-2 text-sm font-semibold">⚠ Status Akhir: TAHAN — KONFIRMASI DOKTER</div>';

  // Interaksi obat badges
  const interaksiBadges = h.klinis.interaksi.map(i => {
    const color = i.tingkat === 'MAYOR' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700';
    return `<div class="${color} rounded-lg px-3 py-2 text-xs mb-2">
      <span class="font-bold">[${i.tingkat}]</span> ${i.deskripsi}
    </div>`;
  }).join('');

  const makeSection = (title, ok, items) => {
    const color = ok ? 'emerald' : 'red';
    const icon  = ok ? '✓' : '✗';
    const list  = items.length > 0
      ? `<ul class="list-disc list-inside mt-1 space-y-0.5">${items.map(i => `<li>${i}</li>`).join('')}</ul>`
      : `<p class="text-${color}-600 mt-1 text-xs">Tidak ada masalah.</p>`;
    return `
      <div class="rounded-lg border ${ok ? 'border-emerald-200 bg-emerald-50' : 'border-red-200 bg-red-50'} p-3">
        <h4 class="font-semibold text-${ok ? 'emerald' : 'red'}-700 text-sm">${icon} ${title}</h4>
        <div class="text-xs text-${ok ? 'emerald' : 'red'}-700 mt-1">${list}</div>
      </div>`;
  };

  document.getElementById('modal-body').innerHTML = `
    ${statusHtml}

    <!-- Info Pasien -->
    <div class="grid grid-cols-2 gap-3 text-xs">
      <div class="bg-slate-50 rounded-lg p-3">
        <p class="text-slate-400 font-medium mb-1">Data Pasien</p>
        <p><span class="text-slate-500">Nama:</span> ${r['nama_pasien']}</p>
        <p><span class="text-slate-500">RM:</span> ${r['no_rm']}</p>
        <p><span class="text-slate-500">J.Kelamin:</span> ${r['jenis_kelamin']}</p>
        <p><span class="text-slate-500">Usia:</span> ${r['usia_tahun'] || '—'} tahun</p>
        <p><span class="text-slate-500">BB:</span> ${r['berat_badan_kg'] || '—'} kg</p>
        <p><span class="text-slate-500">Alergi:</span> ${r['riwayat_alergi'] || '—'}</p>
      </div>
      <div class="bg-slate-50 rounded-lg p-3">
        <p class="text-slate-400 font-medium mb-1">Data Resep</p>
        <p><span class="text-slate-500">Tanggal:</span> ${r['tanggal_resep'] || '—'}</p>
        <p><span class="text-slate-500">Dokter:</span> ${r['nama_dokter']}</p>
        <p><span class="text-slate-500">SIP:</span> ${r['no_sip_dokter'] || '—'}</p>
        <p><span class="text-slate-500">Paraf:</span> ${r['paraf_dokter']}</p>
        <p><span class="text-slate-500">Diagnosis:</span> ${r['diagnosis_klinis']}</p>
      </div>
    </div>

    <!-- Obat -->
    <div class="bg-slate-50 rounded-lg p-3 text-xs">
      <p class="text-slate-400 font-medium mb-1">Daftar Obat &amp; Signa</p>
      <ul class="list-disc list-inside space-y-0.5 text-slate-700">
        ${r['daftar_obat_dan_signa'].split(';').filter(Boolean).map(o => `<li>${o.trim()}</li>`).join('')}
      </ul>
    </div>

    <!-- Checklist Skrining -->
    ${makeSection('Kajian Administratif', h.admin.ok, h.admin.masalah)}
    ${makeSection('Kajian Farmasetik', h.farmasi.ok, h.farmasi.masalah)}
    ${makeSection('Kajian Klinis', h.klinis.ok, h.klinis.masalah)}

    ${h.klinis.interaksi.length > 0 ? `
    <div class="rounded-lg border border-orange-200 bg-orange-50 p-3">
      <h4 class="font-semibold text-orange-700 text-sm mb-2">⚡ Interaksi Obat Terdeteksi</h4>
      ${interaksiBadges}
    </div>` : ''}

    <!-- Rekomendasi -->
    <div class="rounded-lg border border-teal-200 bg-teal-50 p-3">
      <h4 class="font-semibold text-teal-700 text-sm mb-1">💊 Rekomendasi Tindak Lanjut Apoteker</h4>
      <p class="text-xs text-teal-700">${h.rekomendasi}</p>
    </div>

    ${!h.statusLolos ? `
    <!-- Catatan SBAR -->
    <div class="rounded-lg border border-slate-300 bg-slate-50 p-3">
      <div class="flex items-center justify-between mb-2 gap-2">
        <h4 class="font-semibold text-slate-700 text-sm">📋 Catatan Konfirmasi SBAR ke Dokter</h4>
        <button id="btn-copy-sbar"
          class="inline-flex items-center gap-1 text-xs bg-slate-700 hover:bg-slate-800 active:scale-95 text-white px-2.5 py-1.5 rounded-lg transition-all font-medium whitespace-nowrap">
          <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-4 10h6a2 2 0 002-2v-8a2 2 0 00-2-2h-6a2 2 0 00-2 2v8a2 2 0 002 2z"/>
          </svg>
          <span id="copy-sbar-label">Salin ke Clipboard</span>
        </button>
      </div>
      <textarea id="sbar-textarea" readonly
        class="w-full font-mono text-xs text-slate-700 bg-white border border-slate-200 rounded-lg p-3 resize-none focus:outline-none"
        rows="12" spellcheck="false"></textarea>
    </div>` : ''}
  `;

  // Isi textarea SBAR setelah innerHTML di-set (elemen sudah ada di DOM)
  if (!h.statusLolos) {
    document.getElementById('sbar-textarea').value = buildSBAR(r);
    document.getElementById('btn-copy-sbar').addEventListener('click', () => {
      const ta    = document.getElementById('sbar-textarea');
      const label = document.getElementById('copy-sbar-label');
      navigator.clipboard.writeText(ta.value).then(() => {
        label.textContent = '✓ Tersalin!';
        setTimeout(() => { label.textContent = 'Salin ke Clipboard'; }, 2000);
      }).catch(() => {
        // Fallback untuk browser yang tidak mendukung Clipboard API
        ta.select();
        document.execCommand('copy');
        label.textContent = '✓ Tersalin!';
        setTimeout(() => { label.textContent = 'Salin ke Clipboard'; }, 2000);
      });
    });
  }

  const overlay = document.getElementById('modal-overlay');
  overlay.classList.remove('hidden');
  overlay.classList.add('flex');
}

function closeModal() {
  const overlay = document.getElementById('modal-overlay');
  overlay.classList.add('hidden');
  overlay.classList.remove('flex');
}

// ============================================================
// BAGIAN 7: FILTER & PENCARIAN
// ============================================================

/** Mengambil nilai filter aktif dan mengembalikan data terfilter. */
function applyFilters() {
  const statusVal   = document.getElementById('filter-status').value;
  const kategoriVal = document.getElementById('filter-kategori').value;
  const dokterVal   = document.getElementById('filter-dokter').value;
  const searchVal   = document.getElementById('search-input').value.toLowerCase().trim();

  filteredData = masterData.filter(r => {
    const h = r._hasil;

    if (statusVal === 'lolos'  && !h.statusLolos)  return false;
    if (statusVal === 'tahan'  && h.statusLolos)   return false;

    if (kategoriVal === 'administratif' && !h.kategoriMasalah.includes('administratif')) return false;
    if (kategoriVal === 'farmasetik'    && !h.kategoriMasalah.includes('farmasetik'))    return false;
    if (kategoriVal === 'klinis'        && !h.kategoriMasalah.includes('klinis'))        return false;

    if (dokterVal && r['nama_dokter'] !== dokterVal) return false;

    if (searchVal) {
      const noResep = (r['no_resep'] || '').toLowerCase();
      const namaPasien = (r['nama_pasien'] || '').toLowerCase();
      if (!noResep.includes(searchVal) && !namaPasien.includes(searchVal)) return false;
    }

    return true;
  });

  renderKPI(filteredData);
  renderAllCharts(filteredData);
  renderTable(filteredData);
}

/** Mengisi dropdown filter Dokter dari data master. */
function populateDokterFilter(data) {
  const dokterSet = [...new Set(data.map(d => d['nama_dokter']).filter(Boolean))].sort();
  const sel = document.getElementById('filter-dokter');
  dokterSet.forEach(nama => {
    const opt = document.createElement('option');
    opt.value = nama;
    opt.textContent = nama;
    sel.appendChild(opt);
  });
}

// ============================================================
// BAGIAN 8: EKSPOR LAPORAN CSV
// ============================================================

/**
 * Mengekspor data terfilter saat ini ke file CSV yang bisa diunduh.
 * Setiap baris mencakup data resep + hasil skrining (status, kategori masalah, rekomendasi).
 */
function exportCSV() {
  if (!filteredData || filteredData.length === 0) {
    alert('Tidak ada data untuk diekspor.');
    return;
  }

  const headers = [
    'No Resep', 'Tanggal', 'Nama Pasien', 'No RM', 'Jenis Kelamin', 'Usia (th)',
    'BB (kg)', 'Nama Dokter', 'Diagnosis', 'Daftar Obat',
    'Admin OK', 'Farmasi OK', 'Klinis OK', 'Status Akhir',
    'Kategori Masalah', 'Interaksi (Tingkat)', 'Rekomendasi'
  ];

  const rows = filteredData.map(r => {
    const h = r._hasil;
    const interaksiStr = h.klinis.interaksi.length > 0
      ? h.klinis.interaksi.map(i => `[${i.tingkat}] ${i.deskripsi}`).join(' | ')
      : 'Tidak ada';
    return [
      r['no_resep'],
      r['tanggal_resep'] || '',
      r['nama_pasien'],
      r['no_rm'],
      r['jenis_kelamin'],
      r['usia_tahun'] || '',
      r['berat_badan_kg'] || '',
      r['nama_dokter'],
      r['diagnosis_klinis'],
      r['daftar_obat_dan_signa'],
      h.admin.ok   ? 'OK' : 'Masalah',
      h.farmasi.ok ? 'OK' : 'Masalah',
      h.klinis.ok  ? 'OK' : 'Masalah',
      h.statusLolos ? 'Lolos Dispensing' : 'Tahan - Konfirmasi Dokter',
      h.kategoriMasalah.join('; ') || 'Tidak ada',
      interaksiStr,
      h.rekomendasi
    ].map(v => `"${String(v).replace(/"/g, '""')}"`);
  });

  const csvContent = '\uFEFF' + [headers.map(h => `"${h}"`), ...rows]
    .map(r => r.join(','))
    .join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `laporan_skrining_resep_${new Date().toISOString().slice(0,10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ============================================================
// BAGIAN 9: INISIALISASI APLIKASI
// ============================================================

async function init() {
  try {
    // Ambil CSV
    const response = await fetch('data_resep_skrining_200.csv');
    if (!response.ok) throw new Error(`Gagal mengambil CSV: ${response.status}`);
    const csvText = await response.text();

    // Parse dan skrining
    const rawData = parseCSV(csvText);
    masterData = rawData.map(r => {
      r._hasil = skriningResep(r);
      return r;
    });

    // Set state awal
    filteredData = [...masterData];

    // Update status bar
    document.getElementById('data-status').textContent =
      `${masterData.length} resep dimuat · Nov 2026`;

    // Isi dropdown dokter
    populateDokterFilter(masterData);

    // Render semua komponen
    renderKPI(filteredData);
    renderAllCharts(filteredData);
    renderTable(filteredData);

    // Event listeners filter & pencarian
    ['filter-status', 'filter-kategori', 'filter-dokter'].forEach(id => {
      document.getElementById(id).addEventListener('change', applyFilters);
    });
    document.getElementById('search-input').addEventListener('input', applyFilters);

    // Tombol ekspor CSV
    document.getElementById('btn-export-csv').addEventListener('click', exportCSV);

    // Modal tutup
    document.getElementById('modal-close').addEventListener('click', closeModal);
    document.getElementById('modal-overlay').addEventListener('click', e => {
      if (e.target === document.getElementById('modal-overlay')) closeModal();
    });

  } catch (err) {
    document.getElementById('data-status').textContent = 'Error: ' + err.message;
    console.error(err);
  }
}

// Jalankan saat DOM siap
document.addEventListener('DOMContentLoaded', init);
